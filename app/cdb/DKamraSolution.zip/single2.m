clear all;
close all;
frames = [];
for i=1:720
    textFileName = ['plant2/25_side0' sprintf('%03d',i-1) '.jpg'];
    image = im2double(imread(textFileName));
    image = rgb2gray(image)*255;
    image = imresize(image , [45 60]);
%     imshow(image);
    frames(i).frame = image;
end
% % save('frames2.mat' , 'frames');
% load('frames2.mat');
i=1;

time = zeros(1,714);
avg_vs = zeros(1,714);
current_time=0;

for i=1:714
    f = frames(i:i+6);
    [fx,fy,ft]=space_time_deriv(f);
    velocities = zeros(1, 1924);
    x=1;
    for row=5:41
        for column=5:56
            temp_fx = fx(row-3:row+3 , column-3:column+3);
            temp_fx = temp_fx(:);
            temp_fy = fy(row-3:row+3 , column-3:column+3);
            temp_fy = temp_fy(:);
            temp_ft = ft(row-3:row+3 , column-3:column+3);
            temp_ft = temp_ft(:);
            M = [temp_fx'*temp_fx temp_fx'*temp_fy; temp_fx'*temp_fy temp_fy'*temp_fy];
            gradient = sqrt(sum(temp_fx.^2) + sum(temp_fy.^2));
            if cond(M) > 100 || gradient < 10
                v = 0;
            else
                b = [temp_fx'*temp_ft; temp_fy'*temp_ft];
                v = -1*inv(M)*b;
                v = v(2,1);
            end
            velocities(1,x) = (v*480)/45;
            x = x+1;
        end
    end
    avg_vs(i) = mean(velocities);
    time(i) = current_time;
    current_time = current_time+10;
end
plot(time , avg_vs);